# Changelog

## Unpublished filter execution seam

- Pass optional inclusive selected date bounds to consumer search backends so they can filter before limiting candidates. Existing no-date option shape and tag/date-only browsing remain unchanged.
- Make the neutral reference adapter apply AND-tag/date filters before its limit and include all answer-affecting options in its cache identity.
- Prove beyond-50 eligible matches and Date structured-clone behavior through source and packed-consumer tests. No engine, domain or protocol envelope is added to the package.


## 0.1.3 - unpublished review candidate

- Keep visible and announced pending feedback consistent for ready backends and cold debounce windows.
- Verify held positive and empty answers, clear-to-idle behavior, and cold debounce in source and independently installed package regressions.
- Preserve transport, ranking, stale-answer invalidation, and the immutable published 0.1.1 baseline.

## 0.1.2 - unpublished review candidate

- Install modal containment in the layout phase alongside initial input focus, preventing deferred focus stealing after immediate Escape.
- Add independently packed immediate-input-focus/Escape regression without readiness sleeps.
- Treat an active date range as empty-query browse admission and preserve readiness.
- Emit existing consumer-provided palette activation events once for pointer and keyboard selections; native modified links remain native.
- Preserve selected palette identity across provider refreshes and ship neutral date-filter token fallbacks.
- Reconcile current packed install and inline retry documentation.
- Public API, styling, ranking policy and consumer navigation remain unchanged.

Published 0.1.1 bytes remain immutable; this patch is prepared for review without publication.

## 0.1.1 - published baseline

- Use the owner-selected bare npm identity `type-anywhere-search`; previous scoped artifacts remain historical.

- Clean emitted output before packing and omit maps pointing to unshipped source.
- Bundle public API/install/migration documentation, provenance and license notices.
- Add package path/document guards and public npm repository metadata.
- Reconcile ranking/palette APIs and exact consumer/release/rollback evidence.

Runtime behavior is unchanged from private source 2112cc6. Historical private
0.1.0 artifacts have multiple digests; an exact source and hash identify them.
0.1.1 does not promise CommonJS, additional Preact majors, or a bundled stylesheet.

This aggregate PR includes the preserved main-to-published-0.1.1 preparation
stack and separate unpublished static-search package. The 0.1.2 notes above
describe changes relative to the immutable published 0.1.1 baseline, not the
whole historical main-to-head diff.
