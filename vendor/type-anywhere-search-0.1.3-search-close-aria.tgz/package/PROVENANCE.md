# Provenance

## Source archive

- Repository: [`EffortlessMetrics/Under-the-C`](https://github.com/EffortlessMetrics/Under-the-C)
- Archive role: complete private provenance and integration history for the formerly combined publication, template, and search-library work.
- Scaffold-time observation: main `14386707c3a8de1aa6b0fbefe6990af9fbc30370`, tree `e7871e29418154c424105baa1a1dee4c6f492ca4`.

The scaffold-time observation is retained as history only. The frozen split authority below governs this repository.

## Frozen split authority

```text
split_source_commit: 99aa50d864b6358594e2dffef385af45d0777400
split_source_tree: e8489254e5f7a53d6dec4e8f012f38ba84b75f5a
split_manifest_sha256: b84a08c785727b1d7433a100b38b70c46adbe34fd11cb7e608a57668f16f1f51
export_tool_sha256: aff4faace591998d870d4fea23c10c535e27b3dfc87e9b273b231b8fb9251126
source_verification_receipt: 436d72fdb2f5b553ee6525473651cd85b54e4855eed9994e48c571ac52e902cd
```

- Split phase: `frozen`.
- Review-required paths: zero.
- Split violations: zero.
- Exported product files: 50 files / 814,899 bytes.
- Per-file identities and import dispositions: `SPLIT_RECEIPT.json` and `provenance/import-receipt.json`.

The clean history of this repository is **not** the original development history. Pre-import authorship, review, and integration context remain in the private source archive.

## Genesis import

The deterministic export was applied through `scripts/import-split-candidate.mjs --apply` after a reviewed dry run.

- **Copied verbatim:** the original interaction component, subordinate components/hooks, focused behavior tests, shared test utilities, and two legacy how-to documents.
- **Staged then replaced:** 22 generic monolith toolchain files were imported under `.split-seed/`, then replaced by the package's own TypeScript/Preact build and removed.
- **Preserved scaffold controls:** README, AGENTS, this provenance record, SOURCE_BASE, bootstrap/import documentation, repository verifier, workflows, and root bootstrap metadata.
- **Excluded:** archive-only monolith material remained in Under-the-C.

## Native package evolution

The imported source was a behavior baseline, not the final package boundary.

### Coupling removal

The inherited MiniSearch, worker/cache, Carcinisation domain, routing, analytics-provider, and presentation coupling was removed behind the public port contract in the native build-independence work:

- `SearchBackendPort` owns readiness and search execution without naming an engine;
- `SearchNavigationPort` leaves URLs and navigation to the consumer;
- `SearchHistoryPort` supports consumer-controlled persistence identity;
- `SearchAnalyticsPort` emits semantic events without naming a provider;
- result metadata and full-text rendering remain consumer-supplied;
- the library ships no Under the Sea styling and no site-specific modes.

The fixed cold-readiness/cache-poisoning behavior from the source product remains the baseline: queries are not admitted before a backend is authoritative, and unavailable is not represented as a valid empty result.

### Independent package proof

The package is proved through its packed artifact, not source aliases:

- typecheck, 118 behavior tests, package build, and coupling scan;
- `pnpm pack` inventory and manifest inspection;
- a neutral scratch install and Node smoke import;
- an isolated Vite/Preact browser consumer covering activation, readiness, dialog/accessibility semantics, navigation, analytics events, editable-element and IME safety, focus, keyboard shortcuts, and teardown.

### Consumer proof

Carcinisation has replaced its temporary interaction copy with the real package component and publication-owned adapters. The publication retains its engine, index, workers, cache, domain metadata, routes, analytics identity, and result presentation.

The current private EffortlessSteven draft supplies a genuine second packed consumer. Exact current and historical pins, limits and remaining acceptance are recorded in [publish preparation](docs/governance/publish-preparation.md). A neutral fixture establishes package independence but is not a production consumer.

## Current ownership

From the frozen split forward, this repository is the canonical owner of the TypeAnywhereSearch package. Under-the-C remains the historical archive, not an upstream source to be replayed over native package evolution.

Future source changes should enter here first. Consumer integrations should update through package artifacts and explicit receipts.

## License

Steven Zimmerman explicitly authorized the extracted owner-authored code for reuse under **MIT OR Apache-2.0** on 2026-10-04. The grant applies to this package and its owner-authored documentation, fixtures, and examples. Recipients may choose either license; see LICENSE-MIT and LICENSE-APACHE.

The owner decision specifies the expression MIT OR Apache-2.0. This does not change the private Under-the-C archive's license or third-party dependency notices. Private candidate status and the separate registry/publication approval boundary remain in force.
