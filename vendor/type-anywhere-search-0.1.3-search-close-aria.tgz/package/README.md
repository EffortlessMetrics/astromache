# TypeAnywhereSearch

Accessible type-anywhere search interaction for Preact applications.

> **Status:** independently buildable 0.1.3 release candidate in a private repository. Bare `type-anywhere-search@0.1.1` is published; this `0.1.3` candidate and the separate static-search package remain unpublished.

TypeAnywhereSearch was extracted from [`EffortlessMetrics/Under-the-C`](https://github.com/EffortlessMetrics/Under-the-C) at the frozen split recorded in [`PROVENANCE.md`](PROVENANCE.md). The source archive remains the authority for pre-split history; this repository owns the package from that boundary forward.

## Governing goal

Provide a small, explicit, well-tested interaction system for:

- printable-key, `/`, and Cmd/Ctrl+K activation;
- editable-element and IME safety;
- dialog lifecycle and focus management;
- query, debounce, cancellation, and stale-result state;
- loading, error, no-results, and results states;
- keyboard result selection and activation;
- accessible announcements and selected-result semantics;
- optional history and semantic events;
- consumer-owned search, navigation, analytics, and rendering ports.

## Package boundary

Date filtering is a compact accessible disclosure: presets appear on demand, an active range remains visible when collapsed, Escape/selection return focus, and a clear control removes the constraint. It uses the existing date state and does not introduce another dialog.

`rankSearchCandidates(query, candidates)` is an optional engine-independent relevance policy for backend adapters to apply **before** their result limit. Exact title/tag matches precede name prefixes/typos and contextual text; body-only typos require at least five characters, a shared three-character prefix and one edit (including adjacent transposition). Full exact/prefix body discovery remains supported. Equal tiers retain backend order. Pass already searchable text in optional `body`; the package does not own index generation, HTML processing, engines or workers. This policy is opt-in, so existing adapters retain their ordering until they adopt it.

Backend `SearchExecutionOptions` now optionally includes inclusive `dateRange` bounds (`Date | null` start/end). Adapters that limit candidates should apply selected AND-tags and these bounds before the limit; post-answer client filtering cannot restore eligible matches already discarded. No active date selection leaves the original options shape unchanged. Bounds survive structured clone for consumer-owned workers; tag/date-only browsing still uses `getAllDocuments`. See [API responsibilities](docs/reference/api.md).

`getSearchMatchTerms(query, document)` returns the actual tokens admitted by that policy. Adapters can return those in optional `matchedTerms` so typo hits show the matching source text without changing the input. Snippet ranges refer to the emitted snippet and preserve original Unicode text.

Optional `getPaletteEntries()` supplies typed `PaletteEntry` destinations (`href`) or existing actions (`onActivate`). Matching local entries precede articles in the same list and use the same keyboard cursor. Titles and keyword aliases match the input; `suggested` entries appear on an empty input without history. Existing history takes precedence on an empty input. Filters apply to article search and suppress local entries. The callback refreshes labels on opening or typing, so a site can expose its current theme or reading control. Local entries remain available while the backend is unavailable; article readiness and retry remain distinct. Consumers own routes, callbacks, and entry IDs (unique within their entry list); the library creates no actions, modes, command syntax, or tracking.

This repository owns the interaction component, ports, reference adapters, behavior tests, package build, and packed-consumer proofs.

It does **not** own:

- MiniSearch or another production search engine;
- Carcinisation's index schema, generators, workers, cache, memory budgets, filters, or routes;
- Plausible or another consumer analytics identity;
- Under the Sea styling;
- site-specific modes or a speculative framework-agnostic layer.

Preact is a deliberate peer dependency for the current consumers.

See [current publish preparation](docs/governance/publish-preparation.md) for the exact consumer pin and remaining release work. The September candidate receipt remains historical.

## Current state

The extraction and first consumer cutover are complete:

- consumer-domain and theme coupling was carved behind explicit ports;
- 182 package behavior tests cover activation, readiness, focus, IME, keyboard, stale-result, history, analytics, accessible date disclosure and portable relevance;
- `pnpm pack` is part of `verify:repo` and checks the tarball inventory plus a source-alias-free neutral install;
- Carcinisation consumes the real component through publication-owned backend, navigation, analytics, history, and rendering adapters;
- the browser packed-consumer lane proves the installed tarball through an isolated Vite/Preact application;
- the rebuilt private EffortlessSteven consumer uses a qualified vendored tarball, tracked in [personal PR #4](https://github.com/EffortlessSteven/effortlesssteven-site/pull/4); the package runtime qualification is recorded at source commit `2112cc6d106b92c6b30c2ff22244d73524d8f70c`;
- the historical first private semantic version was `0.1.0` (`private: true` retained at that time), with its candidate receipt in [`docs/governance/private-candidate-receipt.md`](docs/governance/private-candidate-receipt.md).

Remaining before any public release:

- review the package and consumer draft PRs and authorize their eventual cutover (post-merge actions remain recorded in the candidate receipt);
- make explicit visibility, registry, and release decisions. The owner-authored MIT OR Apache-2.0 license grant is already recorded in `PROVENANCE.md`.

## Documentation

- [`docs/reference/api.md`](docs/reference/api.md) — public API and ports reference: exports, readiness handshake, state machine, keyboard contract, E2E hooks, limits.
- [`docs/reference/supported-versions.md`](docs/reference/supported-versions.md) — validated Node/pnpm/Preact versions and consumer framework assumptions.
- [`docs/howto/install-from-packed-artifact.md`](docs/howto/install-from-packed-artifact.md) — vendored-tarball installation, sha256 verification, receipt convention.
- [`docs/howto/migration.md`](docs/howto/migration.md) — migrating a consumer-local interaction implementation to the package.
- [`docs/howto/troubleshooting.md`](docs/howto/troubleshooting.md) — observed failure modes and their fixes.
- [`docs/governance/private-candidate-receipt.md`](docs/governance/private-candidate-receipt.md) — the `0.1.0` private candidate: artifact identity, consumer pins, known limitations, rollback, tag plan.

## Verify

Prerequisites: Node 24 and pnpm 10.23.

```bash
pnpm install --frozen-lockfile
pnpm verify:repo
```

`verify:repo` runs the repository contract, typecheck, package tests, build, coupling scan, tarball inspection, Node smoke consumer, and isolated browser consumer.

Start with [repository AGENTS.md](https://github.com/EffortlessMetrics/type-anywhere-search/blob/fix/close-reopen-focus/AGENTS.md), [repository bootstrap plan](https://github.com/EffortlessMetrics/type-anywhere-search/blob/fix/close-reopen-focus/docs/BOOTSTRAP_PLAN.md), and controller [issue #1](https://github.com/EffortlessMetrics/type-anywhere-search/issues/1).

## Package status

The package identity is `type-anywhere-search`, version `0.1.3` - an unpublished release candidate. Its manifest is prepared with `private: false` and public npm metadata; publication remains owner-gated. Public repository visibility, registry publication, and package signing require explicit authorization. The owner-authored license grant is settled as documented below. Historical candidate pins are recorded in [`docs/governance/private-candidate-receipt.md`](docs/governance/private-candidate-receipt.md); current release commands and integration limits are in [publish preparation](docs/governance/publish-preparation.md).

The qualified package lane currently uses TypeScript 7.0.2, Vitest 4.1.11, and pnpm 10.23. Harmonizing those versions with the newer native Astro/Vite Plus consumer stack remains release hardening; it does not invalidate the isolated packed-consumer qualification.

## License

Owner-authored code is licensed under **MIT OR Apache-2.0**, at your option. See `LICENSE-MIT`, `LICENSE-APACHE`, and the explicit owner decision in `PROVENANCE.md`. Third-party dependencies retain their own licenses. This grant does not authorize registry publication or a visibility change.
