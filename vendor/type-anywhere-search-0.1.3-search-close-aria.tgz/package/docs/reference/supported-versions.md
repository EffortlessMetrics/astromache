# Supported versions

The repository is private; the package is an **unpublished 0.1.3 release candidate**. The ranges below are what the
repository and its two genuine consumers actually build and test against —
recorded as *validated in*, not guaranteed elsewhere.

## Runtime and toolchain

| Dependency | Supported | Evidence |
| --- | --- | --- |
| Node | `^24.16.0` (engines) | `.nvmrc` pins `24.21.0`; `verify:repo` runs on Node 24; CI uses `.nvmrc` |
| pnpm | exactly `10.23.0` | `packageManager: pnpm@10.23.0`; the repository-contract verifier fails on any other value; install with `--frozen-lockfile` |
| Preact | `^10.29.8` (peer) | Deliberate peer dependency; the neutral consumer and both real consumers install `10.29.8`; package devDependency matches the peer range |

Older Node may work but is not validated. Other package managers are not
validated. Do not widen these ranges in a consumer report without rerunning
`pnpm verify:repo` from a fresh clone.

## TypeScript

The package builds with TypeScript 7.0.x (native) and ships standard `.d.ts`
declarations without source/declaration maps (the source tree is not shipped) for the single root export. The generated
declarations are consumed by the neutral fixture's strict `tsc --noEmit`
typecheck as part of `verify:repo`, so the published declaration surface is
proved on the toolchain above. Consumers on older TypeScript majors consume
the same declarations at their own risk — validated in on TS 7 only.

## Framework assumptions (validated in consumers)

The package itself is framework-targeted, not framework-coupled beyond its
Preact peer: it renders a Preact subtree and touches no router, meta-framework,
and does not bundle a CSS pipeline. Consumers supply the documented Tailwind utility scanning and theme aliases. Everything else below is **consumer-validated integration
context**, not a package guarantee:

| Consumer | Astro | Vite | Tailwind | Status |
| --- | --- | --- | --- | --- |
| Carcinisation | 7 | Vite (current major) | v4 | historical integration; current isolated candidate lane and exact pins are recorded in publish preparation |
| EffortlessSteven | 7 | 8 | v4 | private draft PR #4; latest qualified pins are recorded by source and digest in consumer receipts |

Historical and current consumers differ in view-transition and routing details, but both consumers
drive the same small port contract — which is the point of the seam. If a
third consumer differs materially, the shared seam contracts rather than
gaining site-specific modes (AGENTS.md).

## What "supported" means while private

Only explicitly qualified source/artifact pairs are validated; branch or semver names alone are insufficient. The exact vendored artifacts identified in
[`docs/governance/private-candidate-receipt.md`](../governance/private-candidate-receipt.md)
record historical pins; current draft evidence is in the [preparation receipt](../governance/publish-preparation.md). The published 0.1.1 baseline is immutable. These unpublished candidates use exact archive pins rather than semver range resolution,
and no LTS commitment. Rollback and re-pin guidance lives in the candidate
receipt.
