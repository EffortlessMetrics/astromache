# API reference

TypeAnywhereSearch is a single-root-export Preact package: everything public
arrives through `type-anywhere-search`. The library owns the
interaction (activation, dialog/focus lifecycle, query/result state, keyboard
selection/activation, accessible announcements, optional history, semantic
events); the consumer owns the search engine, URLs/navigation, persistence
identity, analytics provider, and result presentation through the ports below.

## Root exports

### Values

| Export | Kind | Purpose |
| --- | --- | --- |
| `TypeAnywhereSearch` | component | The search dialog component (default export, re-exported named). |
| `defaultLabels` | `TypeAnywhereSearchLabels` | Default copy/accessible names; spread under consumer `labels` overrides. |
| `noopAnalytics` | `SearchAnalyticsPort` | No-op analytics default. Measuring nothing is a valid consumer choice. |
| `createMemorySearchBackend` | factory | Neutral, engine-free in-memory reference backend (`MemorySearchDocument[]`). For tests, demos, and the packed-consumer proof — not a production engine. |
| `rankSearchCandidates` | function | Optional engine-independent ranking before a backend result limit; equal tiers preserve backend order. |
| `getSearchMatchTerms` | function | Tokens admitted by that ranking policy, suitable for optional result `matchedTerms`. |
| `createLocalStorageHistoryPort` | factory | Adapts the `SearchHistory` store to `SearchHistoryPort`. |
| `SearchHistory` | class (static) | localStorage-backed history store. `SearchHistory.setStorageKey(key)` preserves a consumer's existing storage key across cutover. |
| `DEFAULT_HISTORY_STORAGE_KEY` | `string` | `"type-anywhere-search-history"` — the default storage key. |
| `TAS_SURFACE_TOKENS` | `readonly TasSurfaceToken[]` | The semantic surface-token table (name + light default); see *Styling tokens* below. |
| `DateRangeFilter` | component | Standalone date-preset dropdown used inside the dialog footer. |
| `SearchNotification` | component | Non-intrusive toast (`role="alert"`) for consumer-side notifications; not used by the dialog itself. |
| `ErrorBoundary` | component | Preact render error boundary. Search rejections use the recoverable inline error state, not this latch. |

### Types

`TypeAnywhereSearchProps`, `SearchResultItem`, `SearchAnswer`,
`SearchExecutionOptions`, `BackendState`, `MemoryPressureState`,
`PerformanceViolation`, `SearchBackendPort`, `SearchNavigationPort`,
`SearchHistoryItem`, `SearchHistoryPort`, `SearchAnalyticsPort`,
`TypeAnywhereSearchLabels`, `RenderResultMeta`, `GetFullText`,
`MemorySearchDocument`, `DateRange`, `TasSurfaceToken`, `PaletteEntry`,
`SearchRelevanceDocument`.

## Component props

```typescript
interface TypeAnywhereSearchProps {
  backend: SearchBackendPort;              // required
  navigation: SearchNavigationPort;        // required
  history?: SearchHistoryPort;             // default: localStorage port
  analytics?: SearchAnalyticsPort;         // default: noopAnalytics
  labels?: Partial<TypeAnywhereSearchLabels>;
  renderResultMeta?: RenderResultMeta;     // badges/meters under a result title
  getFullText?: GetFullText;               // lazy snippet upgrade
  getPaletteEntries?: () => readonly PaletteEntry[]; // local destinations/actions
  syncQueryToUrl?: boolean;              // default: true
}
```

- `backend` — the consumer's engine seam. Everything engine-shaped
  (serialized indexes, Web Workers, shards, caches, memory budgets) lives
  behind it in consumer adapters.
- `navigation` — the consumer's URL scheme and navigation mechanism.
  `getResultHref` is required; `navigate` is optional (default: full page load
  via `window.location.href`).
- `history` — persistence seam. Defaults to the localStorage-backed port; pass
  your own to keep history in your own store.
- `analytics` — semantic event sink; defaults to `noopAnalytics`.
- `labels` — partial override of `defaultLabels` (see below).
- `renderResultMeta` — optional `(result) => ComponentChildren` rendered
  between a result's title and summary. This is the seam for consumer domain
  badges/metadata; no domain type enters the package API.
- `getFullText` — optional `(slug) => Promise<string>` lazy full-text source
  used to upgrade result snippets beyond `bodyPreview` when the preview does
  not contain a query term.
- `syncQueryToUrl` - set to `false` when the host owns `?q`. The dialog will
  neither open from nor modify that parameter; other activation still works.

## Local destinations and actions

`PaletteEntry` has `id`, `title`, optional `keywords` and `suggested`, plus
either `{ kind: "destination", href: string }` or
`{ kind: "action", onActivate(): void }`. IDs must be unique within the list.
`getPaletteEntries` refreshes on opening and typing. Matching entries precede
articles and share the keyboard cursor. Suggested entries appear on empty
input when no history exists; history takes precedence. Article filters
suppress local entries. Local entries remain usable while the backend is
unavailable. Consumers own all URLs, actions and labels.

## Optional relevance policy

`rankSearchCandidates(query, candidates)` accepts `SearchRelevanceDocument`
values with `title`, `tags`, `summary` and optional searchable `body`, and
returns the same candidate objects in relevance order. Apply it before your
result limit. Exact title/tag matches precede name prefixes/typos and context;
equal tiers preserve input order. `getSearchMatchTerms(query, document)`
returns the actual admitted tokens. Put those in optional result
`matchedTerms` to highlight typo matches without rewriting the input.
The policy owns no engine, index, HTML processing or worker.

## Labels

```typescript
interface TypeAnywhereSearchLabels {
  dialogLabel: string;              // aria-label for the dialog and input
  inputLoadingPlaceholder: string;  // placeholder while init() is pending
  inputPlaceholder: string;         // placeholder once ready
  semanticSearchEvent: string;      // bridged provider event for a search
  semanticResultClickEvent: string; // bridged provider event for a click
}
```

Defaults (from `defaultLabels`):

```typescript
{
  dialogLabel: "Search projects",
  inputLoadingPlaceholder: "Loading search...",
  inputPlaceholder: "Type to search projects... (/ to focus)",
  semanticSearchEvent: "Search",
  semanticResultClickEvent: "Project Click",
}
```

Override any subset; the rest stay at the defaults. The two
`semantic*Event` names are what the library passes to
`analytics.trackSemanticEvent` — rename them to match your provider's event
vocabulary.

## SearchBackendPort

```typescript
interface SearchBackendPort {
  init(options?: { signal?: AbortSignal }): Promise<void>;
  isReady(): boolean;
  search(query: string, options: SearchExecutionOptions): Promise<SearchAnswer>;
  getAllDocuments?(): Promise<SearchResultItem[]> | SearchResultItem[];
  onMemoryPressure?(handler: (state: MemoryPressureState) => void): () => void;
  onPerformanceViolation?(
    handler: (violation: PerformanceViolation) => void,
  ): () => void;
}
```

### Readiness handshake

`init()` is the readiness handshake:

- **Resolve once the backend can answer searches.** Resolving early lets a
  cold deep-link execute against nothing and present the empty placeholder as
  if it were a real answer.
- **Stay pending while not yet answerable.** The component defers non-empty
  queries while initialization is pending (the admission gate, below).
- **Reject only on definitive failure.** A rejection renders the distinct
  *unavailable* state, never a zero-result state.

`isReady()` is a synchronous probe the component polls every 500 ms while the
dialog is open and not yet ready. It is the recovery path: a backend that
flips to ready (worker restart, index retry) without a second `init()` call is
picked up by the poll, releasing any query deferred by the admission gate.
Note that `init()` itself is invoked once per dialog-open cycle — recovery is
observed through `isReady()`, not by re-running `init()`.

### Throw-don't-fabricate

`search()` **must throw when no backend can answer**. An unavailable backend
is never reported as a successful zero-match answer: a fabricated empty
envelope is indistinguishable from a genuine zero-result, and a result cache
behind the adapter would persist the lie under the same key a real answer
would use. A throw mid-operation renders an inline retry alert, preserves the query and
lets the visitor retry against the same backend; a rejected
`init()` renders the unavailable state ("Search is currently unavailable.").

### Optional members

- `getAllDocuments()` — the tag/date-only browse corpus used when the query is
  empty and tags or a date range are selected. The library applies its own tag and date-range
  filtering to whatever the backend returns, so `search()` may return
  candidates for the query alone. If the adapter limits candidates, it should
  honor all selected tags (AND) and optional inclusive `dateRange` bounds before
  limiting. Otherwise eligible lower-ranked matches can be lost. Missing dates
  are excluded when a date bound is set. The client passes copied `Date` values,
  which survive `structuredClone`/worker messages; no date field is sent with no
  active date filter. Clear/reset restores that original option shape. Cache
  identities must include tags, date bounds and limit when they affect answers.
- `onMemoryPressure` — subscribe to consumer memory advisories. `warning` and
  `critical` levels each surface a transient alert (auto-cleared after 5 s).
- `onPerformanceViolation` — subscribe to consumer performance-budget
  violations. The consumer decides which violations are worth subscribing to;
  environment and forcing policy live with the consumer, not the component.

### Supporting types

```typescript
interface SearchAnswer {
  results: SearchResultItem[];
}

interface SearchExecutionOptions {
  tags: string[];  // selected filter tags at execution time
  limit: number;   // upper bound on results the library will keep
  dateRange?: { start: Date | null; end: Date | null }; // inclusive selected bounds
}

interface SearchResultItem {
  id: string;
  title: string;
  summary: string;
  tags: string[];
  slug: string;
  bodyPreview?: string;  // short preview used for snippet extraction
  date?: string;         // optional ISO date for the date-range filter
}
```

Consumers may carry additional domain fields on their result objects; the
library only reads the declared fields and passes the rest through untouched.

```typescript
type BackendState = "initializing" | "ready" | "failed";
interface MemoryPressureState { level: "warning" | "critical" }
interface PerformanceViolation {
  budgetId: string;
  actualValue: number;
  threshold: number;
}
```

`BackendState` is exported for adapter authors; the dialog tracks readiness
through the `init()`/`isReady()` handshake rather than by polling a state
string.

## SearchNavigationPort

```typescript
interface SearchNavigationPort {
  getResultHref(result: SearchResultItem): string;  // anchors + keyboard activation
  navigate?(href: string): void;                     // default: full page load
}
```

The consumer owns its URL scheme and navigation mechanism (client-side
router, Astro view transition, full page load). Keyboard Enter, result click,
and the result anchor all funnel through `getResultHref`; `navigate` is
optional.

## SearchHistoryPort and SearchHistory

```typescript
interface SearchHistoryItem {
  query: string;
  timestamp: number;
  resultCount?: number;
}

interface SearchHistoryPort {
  add(query: string, resultCount?: number): void;
  getRecent(limit?: number): SearchHistoryItem[];
  clear(): void;
  has(): boolean;
}
```

The default localStorage-backed store keeps at most **10** entries
(`MAX_HISTORY_ITEMS`); duplicates are de-duplicated case-insensitively and the
newest entry wins. The dialog reads at most **5** entries by default. The
store validates entries on read: anything without a string `query` and numeric
`timestamp` is silently dropped.

**Storage-key continuity.** `SearchHistory.setStorageKey(key)` sets the
localStorage key (default `DEFAULT_HISTORY_STORAGE_KEY`). Call it before the
component mounts to keep an existing consumer history across cutover — this is
the seam the real consumers use. A key change with no migration of the old
payload leaves the new key empty (entries under the old key are invisible,
not deleted); see the migration and troubleshooting guides.

## SearchAnalyticsPort

```typescript
interface SearchAnalyticsPort {
  trackEvent(name: string, properties?: Record<string, unknown>): void;
  trackSemanticEvent?(name: string, properties?: Record<string, unknown>): void;
}
```

`trackEvent` receives the library's semantic interaction events:

| Event | Fires when | Properties |
| --- | --- | --- |
| `search` | an admitted search completes | `query`, `resultCount`, `executionTimeMs`, `filters` |
| `zero_results` | a search completes with zero matches | `query`, `filters` |
| `click` | a result is activated | `query`, `resultId`, `resultSlug`, `position` |
| `filter` | a tag or date filter changes | `filterType`, `action` (`add`/`remove`/`set`), `value` |
| `clear` | search is cleared | `type` (`escape`/`shortcut`/`button`) |

`trackSemanticEvent` is the optional bridge for a consumer-level analytics
provider (for example a privacy-friendly page-metrics script). The library
never names a provider; it sends the `labels.semanticSearchEvent` and
`labels.semanticResultClickEvent` names with privacy-minimized properties
(`query_length`, `result_count`, `has_filters` for searches; `project`,
`source`, `position` for clicks).

## Rendering and full-text seams

```typescript
type RenderResultMeta = (result: SearchResultItem) => ComponentChildren;
type GetFullText = (slug: string) => Promise<string>;
```

- `RenderResultMeta` renders consumer domain metadata under the result title.
- `GetFullText` upgrades snippets: if `bodyPreview` contains a query term the
  preview is used directly; otherwise the full text is loaded and a centered
  snippet (~220 characters) is extracted and highlighted. Failed loads fall
  back to the preview. Full text is prefetched on hover/focus.

## Styling tokens (dark-theme seam)

The dialog chrome is styled with semantic CSS custom properties so a
dark-themed consumer overrides **variables under its own selector** — there is
deliberately no theme/mode prop. The dialog neutrals (`bg-white`,
`bg-gray-50`, `text-gray-600`, `border-gray-200`, ...) map onto these tokens:

| Token | Light default | Replaces |
| --- | --- | --- |
| `--tas-surface` | `#ffffff` | `bg-white` (dialog panel) |
| `--tas-surface-muted` | `#f9fafb` | `bg-gray-50` (filters bar, footer) |
| `--tas-surface-raised` | `#f3f4f6` | `bg-gray-100` (kbd chips) |
| `--tas-border` | `#e5e7eb` | `border-gray-200` (section separators) |
| `--tas-border-subtle` | `#f3f4f6` | `border-gray-100` (history rows) |
| `--tas-border-strong` | `#9ca3af` | `border-gray-400` (kbd chips) |
| `--tas-divider` | `#d1d5db` | `bg-gray-300` (filter-bar divider) |
| `--tas-text` | `#4b5563` | `text-gray-600` (body copy, counts) |
| `--tas-text-strong` | `#374151` | `text-gray-700` (footer help) |
| `--tas-text-solid` | `#111827` | `text-gray-900` (kbd glyphs) |
| `--tas-text-muted` | `#6b7280` | `text-gray-500` (meta, empty states) |
| `--tas-text-faint` | `#9ca3af` | `text-gray-400` (dates, clear buttons) |

Mechanics, both halves load-bearing:

- On mount the component injects the defaults once per document as
  `:where(:root) { ... }`. `:where()` has **zero specificity**, so any
  consumer rule targeting the same element — `html[data-theme="dark"]`,
  `.dark`, a scoped `[data-tas-dialog]` rule — wins without `!important`.
  The dialog root also carries `data-tas-dialog="true"` for scoping.
- Every utility carries the same default as an inline `var()` fallback, so
  the light appearance is byte-stable even where inline `<style>` injection
  is blocked by a strict CSP.

Override recipe (in the consumer's own stylesheet):

```css
/* works for html.dark, html[data-theme="dark"], or any ancestor scoping */
html[data-theme="dark"] {
  --tas-surface: #0b1220;
  --tas-surface-muted: #111c33;
  --tas-border: #24304a;
  --tas-text: #cbd5e1;
  --tas-text-muted: #94a3b8;
  /* ...map the remaining tokens to the site's dark palette */
}
```

Default (unthemed) appearance is unchanged from the pre-token markup — the
defaults above are the exact replaced values — so existing light-theme
consumers need no action and no visual change. The `ocean-*` accent seam is
untouched (including white-on-ocean text inside the date filter, whose
contrast belongs to the consumer's `ocean-*` mapping). `TAS_SURFACE_TOKENS`
exports the table (name + default) for consumers that build theme maps
programmatically.

## State machine

The dialog is `null` when inactive. Once activated:

| State | Entry condition | Rendered as |
| --- | --- | --- |
| `loading` | active; `init()` pending | disabled input with `inputLoadingPlaceholder`; spinner "Loading search index..." |
| `awaiting-backend` | non-empty query or selected tags arrived before readiness | loading treatment retained; **the query does not execute** (admission gate) |
| `ready/idle` | `init()` resolved (or `isReady()` poll observed) | enabled input with `inputPlaceholder`; history shown on focus when empty |
| `searching` | query admitted and executing | live region "Searching..." |
| `results` | answer published | result list, count footer |
| `no-results` | answer published empty | "No results found" (+ query/tag text) |
| `error` | `search()` threw mid-operation | inline alert and Retry search action; the dialog and query remain available |
| `unavailable` | `init()` rejected and `isReady()` stayed false | "Search is currently unavailable." (red) — never a zero-result render |

Transitions of note:

- **Activation** (`loading`): any accepted activation key opens the dialog and
  starts the readiness handshake. `init()` is called once per open cycle.
- **`loading` → `ready`**: `init()` resolves, or the 500 ms poll sees
  `isReady()` true. `window.__searchReady` flips to `true`.
- **`loading` → `unavailable`**: `init()` rejects. The poll keeps watching
  `isReady()`; recovery flips to `ready` and releases deferred queries.
- **`awaiting-backend` → `results`/`no-results`**: readiness flips; the
  deferred query executes exactly once. This is the cold-readiness admission
  gate: a non-empty query arriving before readiness does not execute, so the
  empty pre-readiness envelope can never be cached as a real answer.
- **Stale-result rejection**: every execution carries a monotonic request id;
  only the newest in-flight search may publish results or errors. Rapid
  typing or filter churn discards superseded answers, and clearing the query
  or closing the dialog bumps the identity synchronously, so a response that
  arrives after either action is discarded — it can neither repopulate
  results under an empty query nor rewrite the cleared query into history.
  While closed, the search effect does not run at all, so a pending debounced
  query cannot trigger a fresh execution after close.
- **Recoverable search errors**: a rejected `search()` displays an inline
  alert without replacing the dialog or losing its query. Retry search
  admits a new request for the same query; new input clears the error and
  follows normal debounce. Escape and outside-click remain available.
  Request identity still prevents superseded errors or results publishing.
- **Modal containment**: Tab and Shift+Tab stay inside the dialog. Background
  sibling subtrees become inert while it is open, with their prior inert
  state restored on close or unmount. The package does not assume consumer
  selectors such as `main` or `footer`.
- **Native result links**: result text is an anchor using the navigation
  port's href. Modified and middle clicks retain browser behavior; an
  ordinary activation uses the consumer navigator. Tag buttons remain
  outside anchors.
- **Escape / click-outside / overlay mousedown**: dialog closes; query,
  results, and filters reset; `?q=` is removed from the URL; any in-flight
  search is invalidated; focus returns to the element that was focused at
  activation (captured on every open transition; restored only if it is
  still connected — otherwise the browser default, `document.body`,
  applies). Result-activation close is the exception: navigation hands
  focus to the destination and deliberately does not restore.

## Activation and keyboard contract

Global listeners attach on mount (and detach on unmount) while the dialog is
closed; once open, the input owns typing.

Type-anywhere activation is enabled by default. The existing search dialog
contains a native **Type-anywhere search** checkbox in its footer. Unchecking
it disables slash and all printable-key activation outside the dialog, as
well as the optional character-only navigation keys inside the dialog.
Explicit `openSearch` events, Cmd/Ctrl+K, typing into the searchbox, arrows,
Enter and Escape remain available. The preference is stored locally, per
origin, under `type-anywhere-search:character-shortcuts` (`on` / `off`);
if storage is unavailable it remains effective for the current mount.
The preference is separate from search history and is not sent to analytics.
There is no main-page setting or new popup. The dialog scrolls on short
viewports so its footer is reachable even with populated history. Hosts may
override the preference label and accessible help with `characterShortcutsLabel`
and `characterShortcutsHelp`, and supply an optional
`inputPlaceholderWithoutCharacterShortcuts` through `labels`. Consumers should
not add unconditional instructions promising character activation after opt-out.

| Key | When closed | When open |
| --- | --- | --- |
| printable `a-zA-Z0-9` | open dialog, seed input with the key | typed into input |
| `/` | open dialog, empty query | focus the input (vim-style) |
| `Cmd/Ctrl+K` | open dialog, empty query | — |
| `Escape` | — | close, clear, `clear` event (`type: escape`) |
| `↑`/`↓` | — | move selection |
| `j`/`k` | — | move selection (only when not typing in a field) |
| `g`/`G` | — | first/last result (only when not typing) |
| `x` | — | clear all filters (`clear` event `type: shortcut`) |
| `Enter` | — | activate selected result or history entry (native buttons keep Enter) |

Editable-element and IME safety: activation ignores keypresses originating in
`INPUT`/`TEXTAREA` or any contentEditable region, ignores printable-key
activation with Ctrl/Meta held, and ignores keypresses flagged
`isComposing`. Inside the dialog, the input tracks composition
(`compositionstart`/`compositionend`): interim composition strings never
execute against the engine and never reach the `?q=` sync; the committed
string flushes exactly one search at `compositionend`, and dialog shortcuts
(Escape/Enter/arrows) stay with the IME while composing. The vim keys
(`j`/`k`/`g`/`G`/`x`) apply only when enabled, focus is within the search dialog and is not in an editable field, and
result-level tag buttons own their Enter/click handling so interactive
controls inside results are not swallowed.

## DOM events in and out

- `openSearch` — `document` CustomEvent the consumer can dispatch (for example
  from a header button) to open the dialog.
- `selectTag` — `document` CustomEvent with `detail.tag`; opens the dialog and
  adds the tag to the filter set.

## E2E contract surface

Stable hooks consumers and their test suites can rely on:

- `window.__searchReady: boolean` — mirrors backend readiness (flips when the
  readiness handshake settles). The primary E2E synchronization signal.
- `data-search-hydrated="1"` — set on `<html>` while the component's global
  key listeners are attached; removed on unmount. Wait for it before
  dispatching synthetic key events.
- `?q=<query>` deep link (unless `syncQueryToUrl` is false) - on mount, a non-empty `q` parameter opens the
  dialog with the query applied. While open, the active debounced query is
  mirrored into `?q` via `history.replaceState`; closing removes it.
- Live region — a `sr-only` `aria-live="polite"` `aria-atomic="true"` region
  announces `Searching...`, `Search is unavailable in this environment.`, `No
  results found`, or `Found N result(s)`.
- Dialog semantics — `role="dialog"`, `aria-modal="true"`,
  `aria-label={labels.dialogLabel}`; inner panel `role="search"`; input is
  `type="search"` with `aria-autocomplete="list"`,
  `aria-controls="search-results"`, `aria-activedescendant="search-result-N"`;
  results are `role="list"` / `role="listitem"` with `aria-selected`.

## Limits

| Limit | Value | Where |
| --- | --- | --- |
| Max results kept per execution | 50 (`MAX_SEARCH_RESULTS`) | passed to `search()` as `options.limit` and bounds rendered rows |
| Debounce | 300 ms | query → execution |
| Readiness/recovery poll | 500 ms | `isReady()` while open and not ready |
| History storage cap | 10 entries | `SearchHistory` |
| History display default | 5 entries | `history.getRecent()` default |
| Snippet length | ~220 chars | snippet extraction |
| Advisory auto-clear | 5 s | memory/performance alerts |

Test-hook gating (for example only surfacing forced performance violations
under `import.meta.env.DEV` or a CI flag) is a consumer-side policy decision —
see the consumer ADR-014 pattern; the library only reports what the adapter
subscribes to.

The optional `rankSearchCandidates` helper uses any-term admission and name-first
quality tiers; it does not impose AND-query semantics on consumer engines.
Consumers that require every term must supply their engine-filtered candidates.
