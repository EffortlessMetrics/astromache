# Publish preparation — 2026-10-06

## Current unpublished draft

Owner-selected npm identity is `type-anywhere-search`; older scoped archives remain immutable historical evidence.

Published baseline is bare type-anywhere-search@0.1.1, source a393d88086f8b9859fa3706fea638220c35403b0, SHA256 c469555df36aa7b95416061570fad9a82e6e29dad9392a5bdfcd74e43d34db54. Its bytes remain immutable. Repository visibility remains private; no new publication is authorized.

Current unpublished interaction candidate is 0.1.3, which repairs pending visible and announced feedback without changing transport or ranking. Historical 0.1.2 runtime fixes qualified at 06df1a10fb4b7f9f26f391797b9ad68e26b4ace6: 190 units, 20 independently installed Chromium cases, native declarations/build/import and archive hygiene guards. Required exact-source CI reruns the full gate; final archives must be identified by source plus digest in consumer receipts, not version alone.

Standalone @effortlessmetrics/static-search@0.1.0 is unpublished. Generation-local initialization cleanup first qualified at 3a5a2439dc6159475f21dc6431f52eb00cbe4625. Subsequent single worker-plus-fallback deadline and patient-sibling isolation repairs qualified at 9b91b49282165b9c09e9ac5fa848aa98b281fa3f: 24 source and 24 independently installed contracts, strict isolated declarations and seven-file pack guards. Subsequent default transport-only timeout recovery and adversarial caller-admission regressions bring the current source and independently installed contract count to 32. Checks cover suppressed fallback dispatch after abort/deadline, pre-aborted init and orphan-rejection observation, and synchronous worker/fallback results that finish beyond the caller deadline; the current exact repair source and digest are recorded in consumer receipts. Homepage metadata targets stable main. Engine/ranking, schema, routing, cache policy and telemetry remain consumer-owned.

EffortlessSteven PR4 and isolated Carcinisation PR36 consume actual vendored archives. Current repins and acceptance are recorded in each consumer receipt; preparation does not assert acceptance for a later untested repin. The earlier 2112/17-case package, personal 17/62 and Car 17-plus-skipped receipts are historical. Current Car lane requires 18 real search browser cases with no skips, plus its worker tests, native build/types and seam/hash validation. Main landing additionally requires genuine independent GitHub approval and resolved review threads; local technical review cannot replace that gate.

## Artifact contract

The root ESM export carries declarations; Preact `^10.29.8` is the sole peer.
No runtime dependency, search engine, routes, site corpus, worker or provider identity
is bundled. Browser interaction requires DOM; plain Node import is tested.
The package uses Tailwind utility classes and inherited `ocean-*` accent aliases;
consumers scan emitted markup and map these aliases into their own theme.
This styling integration is explicit, not a self-contained stylesheet guarantee.

Generated output is cleaned before build. Maps to absent sources are omitted.
Public API/how-to documentation, provenance and both owner license notices are
packed. The pack verifier rejects credential/test/source entries, maps and
private machine paths. Node import and strict isolated declaration consumption
prove runtime/type boundaries without source aliases. Chromium proves browser
behavior; additional framework/peer majors and CommonJS are not promised.

## Provenance and genuine consumers

Owner-authored MIT OR Apache-2.0 grant is settled. Preact remains a peer with
its own MIT license; development tools do not enter the runtime archive.
Frozen import provenance is in PROVENANCE.md. No third-party provenance issue
was identified in this pass.

The frozen Under-the-C archive establishes origin, not current package adoption. Its issue417 routes integration to Carcinisation. Historical PR35 and earlier private-candidate receipts remain evidence of their own revisions only; PR36 and personal PR4 receipts establish current actual-consumer pins and acceptance. No new licensing decision is needed.

## Release commands and rollback

From an immutable reviewed source checkout on the supported toolchain:

```sh
pnpm install --frozen-lockfile
pnpm release:check
pnpm pack --pack-destination release-artifacts
npm publish --dry-run --ignore-scripts release-artifacts/type-anywhere-search-0.1.3.tgz
```

The dry run does not prove npm authentication or organization scope rights.
After separate explicit publication approval, use the same reviewed archive
with `npm publish --access public --registry https://registry.npmjs.org/ <archive>`.
Do not rebuild, retag, repin or replace artifact bytes during that transaction.
Verify registry integrity against the approved SHA256 after publication.


No publication script, registry credentials, public tag or visibility change is
introduced. Before a public release: approve destination/visibility and release
ownership, approve the prepared 0.1.3 immutable release artifact, rerun the full
package gate and genuine consumer acceptance, and record source/tree/digest.
Multiple private 0.1.0 archives are identified by source plus SHA256; version
alone must never select bytes. The candidate manifest is now publishable; executing publication remains a
separately authorized transaction. Validate target peer/toolchain ranges
rather than widening them based on a successful build alone.

For upgrade, retain previous vendor archive/receipt and lockfile, install the
new exact archive, run the site-specific acceptance and offline checks, then
review the pin change. For rollback, restore that previous archive, receipt,
manifest and lock together and repeat those checks. Package prep does not
silently change either website. Deployment and live smoke remain separate.
