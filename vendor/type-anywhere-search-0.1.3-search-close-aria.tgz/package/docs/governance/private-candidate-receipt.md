<!-- Historical candidate receipt: current private draft pins and limits are in publish-preparation.md. Do not use this September receipt as current acceptance. -->

# Private candidate receipt — `@effortlessmetrics/type-anywhere-search` 0.1.0

This receipt identifies the exact package artifact and source SHA for the
first private semantic candidate, records both consumer pins it supersedes,
and fixes the post-merge actions (tag, consumer re-pins). Issue #5.

## Candidate identity

| Field | Value |
| --- | --- |
| Package | `@effortlessmetrics/type-anywhere-search` |
| Version | `0.1.0` (`private: true` retained; publication remains owner-gated) |
| Candidate source commit | `1e0b2358b1b6547af7543341f3ee3bdab8a6ebf5` (branch `chore/0.1.0-private-candidate`) |
| Candidate source tree | `ffa2e520a291a6b3dfadf5d004382617b67fb761` |
| Tarball | `effortlessmetrics-type-anywhere-search-0.1.0.tgz` |
| Tarball SHA-256 | `bc5054d2326be9c36f93adffe449c820cac54c5a6d5f06597c1e9cf851dd3b4f` |
| Packed | 2026-09-20, `pnpm pack` (prepack build) from the candidate commit |
| Previous version | `0.0.0-private` at source commit `db10b8bc8e00da1d90a72901b237276a27fb8e47` (`main` head before this branch) |

This is the third 0.1.0 candidate build. Build one (`df5e0ad`, tarball
`6c3a8ba9…`) was docs/proof-only; build two (`b5f9241`, tarball
`75b43ace…`) added the two EffortlessSteven#313 review fixes; this build
adds the two defects proven by Carcinisation's skeptical reader-acceptance
journey (IME composition in-dialog, focus restoration on close — see
*Review fixes* below). The tarball ships `dist/` output and declarations,
`package.json`, and `README.md` only; the pack lane asserts no sources,
tests, or credential material. The tarball digest was stable across
repeated packs of the same tree, so documentation-only commits on this
branch do not disturb it.

## Review fixes (EffortlessSteven#313 bot review)

Both findings are fixed in this artifact; each carries discriminating tests
(positive and negative) and full-lane verification:

1. **Stale in-flight request survives clear/close** (thread
   `PRRT_kwDOQhCMfs6kHwQd`). The request identity was only bumped when a new
   search started, so a response arriving after the user cleared the input
   or closed the dialog repopulated stale results under an empty query and
   re-added the cleared query to history. Clearing to empty (typed or via
   the clear button) and every close path (Escape, click-outside, overlay
   mousedown, result-activation) now invalidate in-flight requests
   synchronously, the empty-query effect discards stragglers, and the search
   effect guards on `isActive` so a closed dialog cannot start a fresh
   execution from the trailing effect re-run. This defect also affected
   Carcinisation; the fix is package-side so both consumers get it on
   re-pin. (This also removes the former "close re-executes a pending
   query" known limitation.)
2. **Dark-theme neutrals** (thread `PRRT_kwDOQhCMfs6kHwQf`). The dialog
   hardcoded light neutrals. The dialog chrome now uses 12 semantic
   `--tas-*` CSS variables (defaults equal to the exact replaced values),
   injected once as zero-specificity `:where(:root)` rules with inline
   `var()` fallbacks per utility; consumers override the variables under
   their own dark selector (e.g. `html[data-theme="dark"]`). No theme/mode
   prop was added; `TAS_SURFACE_TOKENS` exports the table. Carcinisation's
   default (light) appearance is unchanged — defaults are byte-stable — so
   it is unaffected unless it opts into overrides.
3. **No IME composition guarding inside the dialog** (Carcinisation
   `test.fixme` witnesses on `reader-journey.spec.tsx`, tracked from
   carcinisation #5/#6). Interim composition strings fired the debounced
   search and were published to `?q=`. The input now tracks
   compositionstart/compositionend: while composing, state, search
   execution, and URL sync are suppressed; compositionend flushes exactly
   one search with the committed string; dialog shortcuts stay with the IME
   while composing. Activation guards skip `e.isComposing` and
   contentEditable targets per the documented boundary. New
   `TypeAnywhereSearch.ime-composition.test.tsx` plus browser-lane coverage
   (contentEditable editor fixture; in-dialog composition test).
4. **No focus restoration on close** (same Carcinisation witnesses).
   Escape/click-outside/backdrop dropped focus to `document.body`. Every
   activation path captures the pre-open active element; every deactivate
   path except result-navigation restores it when still connected (else the
   browser default body fallback). New
   `TypeAnywhereSearch.focus-restoration.test.tsx` (positive restore for
   all three close paths, negative navigation case, disconnected fallback,
   repeated cycles).

## Verification at the candidate commit

`pnpm verify:repo` at `1e0b2358b1b6547af7543341f3ee3bdab8a6ebf5` (also run
at each earlier candidate state, and re-run at the branch tip after this
receipt lands), plus a fresh-clone run:

- **Repository lane** — repository bootstrap and source-alignment contract
  passed (scaffold invariants, `private: true`, `packageManager:
  pnpm@10.23.0`).
- **Package lane** — typecheck passed; 133 behavior tests passed (20 files,
  incl. the stale-invalidation, theme-token, IME-composition, and
  focus-restoration suites); build passed; coupling scan found no
  consumer-domain/theme terms.
- **Pack lane** — tarball named for the declared package; ships
  `dist/index.js` + `dist/index.d.ts`; no sources/tests/credentials; exports
  map and preact peer intact; neutral consumer installed the tarball and
  smoke-imported the **full** runtime root export surface (component,
  reference backend, history store + port, date-range filter, notification,
  error boundary, labels, noop analytics, storage key constant, surface
  tokens).
- **Isolated browser packed-consumer lane** — Vite/Preact fixture installed
  from the tarball: typecheck passed (resolving every public type from the
  packed declarations), build passed, 5 Playwright tests passed (readiness
  gate with the manually released `init()` witness, editable/contentEditable
  and composition activation safety, bounded dialog lifecycle, dark-theme
  token override computed-style check, in-dialog IME composition commit).
- **Fresh-clone verification** — clone of this repository at the branch tip,
  `pnpm install --frozen-lockfile` clean on Node `v24.21.0` / pnpm
  `10.23.0`, `pnpm verify:repo` exited 0 with all four lanes green.

Export/declaration audit behind the extended smoke: `dist/index.js` and
`dist/index.d.ts` cover all 11 runtime exports and all 18 public types from
the root; the audit found no missing declarations. It did find, and this
branch closed, two proof gaps: the Node smoke previously skipped four
runtime exports, and the browser fixture's typecheck only exercised 4 of 17
public types. Both now fail the lane if they regress.

## Consumer pins this candidate supersedes

The two consumers currently pin **different** artifacts of the
`0.0.0-private` line. This candidate supersedes both; final re-pins happen
after this lands (see post-merge actions).

| Consumer | Pin | Source commit | Tarball SHA-256 |
| --- | --- | --- | --- |
| Carcinisation | vendored `vendor/type-anywhere-search/effortlessmetrics-type-anywhere-search-0.0.0-private.tgz` + `RECEIPT.json` | `16d7a9912ea7840322f96e730a84540b3de53c97` | `186e78595742f3fb2382939b89df34e61cea0ebec0992636e4ee454dd3cb265a` |
| EffortlessSteven | vendored tarball pin under review (PR #313) | `db10b8bc8e00da1d90a72901b237276a27fb8e47` | `a377594515e182fe97b21337e826de4c59e79f6754f0abf471afd1cf171b396e` |

The Carcinisation receipt's `whyNotGitForm` records why consumption is a
vendored tarball plus hash-checked receipt rather than a git dependency
(CI token scoping); see
[`docs/howto/install-from-packed-artifact.md`](../howto/install-from-packed-artifact.md).

### Final consumer SHAs — FILLED POST-MERGE

<!-- POST-MERGE: record the exact re-pinned artifacts and consumer commits
     after both consumers have cut to 0.1.0. Do not fill before merge. -->

- [ ] Carcinisation re-pin: artifact + source commit + consumer SHA — TBD
- [ ] EffortlessSteven re-pin: artifact + source commit + consumer SHA — TBD

## Known limitations

Deliberately truthful about the current surface:

- **Error-boundary latch.** A `search()` throw mid-operation renders the
  error fallback and latches for the component's mount; close/reopen cannot
  recover (the stored error only clears on a successful search the stuck
  dialog cannot reach). Recovery requires unmount/remount (page reload).
  Proved with a focused repro during this audit; recorded in
  [`docs/howto/troubleshooting.md`](../howto/troubleshooting.md) and the
  [API reference](../reference/api.md) state machine. Follow-up fix
  material — adapters should keep transient failures behind retry/fallback
  so the port only sees definitive failures.
- **Init settles once per open cycle.** `init()` is invoked once per
  dialog-open cycle; recovery after a failure is observed through the
  `isReady()` poll (500 ms) while the dialog stays open. There is no
  automatic re-init; closing and reopening re-runs the handshake from
  scratch.
- **`ocean-*` styling tokens are inherited presentation.** `ocean-deep`,
  `ocean-top`, `ocean-light`, `ocean-dark` are Under the Sea theme names the
  shipped markup still references. Consumers must map these tokens into
  their own theme, and Tailwind v4 consumers need an `@source` entry for the
  package or the dialog renders unstyled. Dark neutrals are *not* a
  limitation: they are covered by the `--tas-*` surface tokens (see *Review
  fixes*). See the migration and troubleshooting guides.
- **History caps.** The default localStorage store keeps at most 10 entries
  and the dialog displays at most 5 by default. Entry validation (string
  `query`, numeric `timestamp`) silently drops anything else — relevant when
  migrating legacy payloads.
- **Single-instance semantics.** One dialog mount per page is the validated
  scenario; the module-level default history port is shared across mounts
  (pass per-mount `history` ports if that ever changes).
- **No registry distribution.** `private: true`; the only distribution is
  the vendored tarball pattern above. No semver range resolution, no
  provenance/signing service.
- **Validated-in, not guaranteed-elsewhere.** Toolchain and framework
  support claims are exactly what the two consumers validated; see
  [`docs/reference/supported-versions.md`](../reference/supported-versions.md).

## Rollback

Rollback restores the previous `0.0.0-private` artifact pins in consumers:

- Carcinisation: keep/restore `vendor/type-anywhere-search/effortlessmetrics-type-anywhere-search-0.0.0-private.tgz`
  (SHA-256 `186e78595742f3fb2382939b89df34e61cea0ebec0992636e4ee454dd3cb265a`,
  source commit `16d7a9912ea7840322f96e730a84540b3de53c97`) and its existing
  `RECEIPT.json`.
- EffortlessSteven: keep/restore the PR #313 pin (source commit
  `db10b8bc8e00da1d90a72901b237276a27fb8e47`, SHA-256
  `a377594515e182fe97b21337e826de4c59e79f6754f0abf471afd1cf171b396e`).

The 0.1.0 candidate carries four package-side behavior fixes over the
`0.0.0-private` pinned artifacts (stale-request invalidation on clear/close,
the `--tas-*` dark-theme surface tokens, in-dialog IME composition
guarding, and focus restoration on close — see *Review fixes*); the
interaction contract is otherwise unchanged, and no consumer adapter code
needs to change in either direction. Rolling back re-accepts the four
review-flagged defects.

## Post-merge actions (pending — not performed by this PR)

1. **Tag** `v0.1.0-private` at the merge commit on `main`. (Plan recorded
   here; the tag is intentionally not pushed from the branch.)
2. **Consumer re-pins.** Pack `0.1.0` at the merge commit, vendor into
   Carcinisation and EffortlessSteven with updated `RECEIPT.json` files, run
   each consumer's verification lane, then fill the "Final consumer SHAs"
   section above in a follow-up commit.
3. **Ruleset/description.** Configure the `main` ruleset (PR required,
   `verify/repository-contract` status, review-thread resolution, deletion
   and force-push protection) and the repository description per issue #1 —
   bounded owner actions, tracked there.
4. **Follow-up fix.** Error-boundary recovery after transient `search()`
   failures (see Known limitations).
