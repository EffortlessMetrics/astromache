# How-To Guide: Search Error Handling with a Custom Backend

TypeAnywhereSearch owns the interaction-side error states; your backend
adapter owns the engine-side failure modes. This guide describes the
`SearchBackendPort` contract the component relies on to keep a cold deep-link,
a crashed engine, and a genuine zero-result search distinguishable.

## The contract

```typescript
import type { SearchBackendPort } from "type-anywhere-search";

const backend: SearchBackendPort = {
  // Readiness handshake: resolve when the backend can answer searches.
  // Keep pending while not yet answerable; reject only on definitive failure.
  async init() {
    await loadIndex();
  },

  // Synchronous probe used for recovery after a failure.
  isReady() {
    return index !== null;
  },

  // Execute a search. Throw when no engine can answer; never return a
  // fabricated empty answer for an unanswerable query.
  async search(query, { tags, limit }) {
    return { results: engine.search(query).slice(0, limit) };
  },
};
```

## Error states and who produces them

| Observable state | Cause | Owner |
| --- | --- | --- |
| `Loading search index...` | `init()` pending; queries are deferred | interaction |
| `Searching...` (live region) | a query was admitted and is executing | interaction |
| `No results found` | backend answered with zero matches | genuine zero result |
| `Search is currently unavailable.` | `init()` rejected and `isReady()` stays false | backend failure |
| `Search is temporarily unavailable...` | `search()` threw mid-operation | engine failure |
| Memory/performance alert | `onMemoryPressure` / `onPerformanceViolation` advisory | consumer infrastructure |

## Rules that keep the states honest

1. **Never resolve `init()` before the backend can answer.** Resolving early
   lets a cold deep-link execute against nothing and present the empty
   placeholder as if it were a real answer.
2. **Never return a fabricated empty answer.** If no engine can answer,
   throw. The component renders the error boundary; an empty answer would be
   indistinguishable from a true zero-match and any cache behind your adapter
   would persist the lie.
3. **Keep `isReady()` truthful after failures.** The component polls it for
   recovery; a backend that recovers (worker restart, index retry) must start
   returning `true` so deferred queries can execute without a retype.
4. **Caching lives behind the adapter.** The component re-executes
   `search()` for every admitted query; cache keys, TTLs, and eviction are
   consumer infrastructure. Only cache answers the backend actually produced.
5. **Gate advisories in the adapter.** `onPerformanceViolation` handlers
   receive every violation you subscribe to; environment gating
   (development-only alerts, forced test alerts) is the consumer's policy,
   not the component's.

## Example: an adapter with cache and retry

```typescript
const cache = new Map<string, SearchAnswer>();

const backend: SearchBackendPort = {
  async init() {
    await engine.ready;
  },
  isReady: () => engine.readyState === "ready",
  async search(query, options) {
    const key = cacheKey(query, options.tags);
    const hit = cache.get(key);
    if (hit) return hit; // only answers the engine produced are cached

    const answer = { results: engine.search(query, options) };
    cache.set(key, answer);
    return answer;
  },
  onMemoryPressure(handler) {
    return memoryBudget.onPressure(handler); // returns unsubscribe
  },
};
```

## History and analytics failures

History and analytics are ports too (`history`, `analytics` props). The
default localStorage history port fails silently when storage is unavailable;
a custom port should do the same. The default analytics port is a no-op —
wire `trackEvent`/`trackSemanticEvent` to your provider; keep provider
identity (and its privacy policy) in your adapter, never in the library.
