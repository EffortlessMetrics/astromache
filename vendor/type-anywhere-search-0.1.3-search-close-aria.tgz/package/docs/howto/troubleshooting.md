# Troubleshooting

Entries are grounded in failure modes actually observed during extraction and
consumer cutover — not speculation. Each follows symptom → cause → fix →
verify.

## Cold deep-link shows "No results found" for a query that should match

**Symptom.** Loading a page with `?q=<valid query>` while the search index is
still cold shows a zero-result answer, and the wrong answer persists — a later
reload or re-query keeps serving the empty result.

**Cause.** The pre-extraction cold-readiness defect: a non-empty query
executed against a backend that could not answer yet, received an empty
placeholder envelope indistinguishable from a genuine zero-match, and a
result cache persisted that lie under the same key a real answer would use.
This was fixed before extraction and is a baseline behavior, not
compatibility surface.

**Fix.** In the package, the admission gate defers any non-empty query that
arrives before the readiness handshake settles; readiness flip re-runs the
deferred query exactly once against the now-authoritative backend. Adapters
must cooperate: `init()` resolves only when the backend can answer (see
[worker init timeout](#the-dialog-spins-forever-or-stays-disabled) below),
and `search()` throws rather than fabricating an empty answer.

**Verify.** The neutral packed consumer is the deterministic witness: its
fixture backend's `init()` returns a manually held promise
(`window.__releaseTypeAnywhereBackend()`). The e2e opens search with a real
keypress while `init()` is pending, fills the input, releases the backend,
and observes the same pending query complete — no retype, no fabricated zero
result. `pnpm verify:repo` runs this on every change.

## The dialog spins forever (or stays disabled)

**Symptom.** The dialog opens, the input stays disabled with the loading
placeholder, and the spinner never resolves; `window.__searchReady` never
becomes true.

**Cause.** The backend's `init()` never settles. With a Web Worker or remote
index this is usually a consumer-adapter timeout policy gap: the worker
message that would resolve readiness is lost, the fetch hangs, or the
fallback path never fires. The component treats a permanently pending
`init()` as "still loading" by design — it cannot distinguish a slow backend
from a dead one.

**Fix.** Put the timeout policy in the adapter, not the component:

- If a missing index should be recoverable/retryable, keep `init()` pending
  and make `isReady()` truthful when a retry succeeds — the 500 ms readiness
  poll picks recovery up while the dialog stays open.
- If the backend has definitively failed (worker crashed, index fetch
  exhausted retries), reject `init()` so the component renders the distinct
  unavailable state instead of an endless spinner.

**Verify.** Unit-test the adapter with a held/rejected init; in the browser,
a rejected `init()` must render "Search is currently unavailable." (and the
live region "Search is unavailable in this environment."), while a held-then-
resolved `init()` must release the deferred query exactly once (the neutral
consumer's readiness-release witness covers the package side).

## "Unavailable" and "zero results" are confused

**Symptom.** Users (or tests) see "No results found" when the search
infrastructure is actually down, or "Search is currently unavailable." when
the query simply matched nothing.

**Cause.** An adapter that returns a fabricated empty answer —
`{ results: [] }` — when no engine could answer. An empty envelope is
indistinguishable from a true zero-match, so the component renders the
no-results state; and any cache behind the adapter persists the fabricated
answer under the real query key.

**Fix.** Follow throw-don't-fabricate. When no backend can answer, `search()`
throws and `init()` rejects; the component renders the error-boundary
fallback (mid-operation failure) or the unavailable state (readiness
failure). Reserve the empty answer for a backend that genuinely searched and
found nothing.

**Verify.** The unavailable state renders only when `init()` rejected and
`isReady()` stayed false; a thrown `search()` renders the temporary-
unavailable fallback; `zero_results` analytics fire only for genuine empty
answers. The package's error-integration suites assert each distinct state.

## A transient engine error

A rejected `search()` now keeps the dialog, query, Escape and outside-click
available. Use **Retry search** for the same query, or edit the query to
admit another search through the normal debounce. A late result/error from
an invalidated request must not overwrite the newer state.

The September 20 pinned 0.1.0 artifact instead latched its error boundary
and required a reload. That historical limitation remains in its receipt;
consumers need the follow-up artifact before they gain recovery. Do not
claim their old pin has changed just because this source branch is fixed.

The consumer-parity component and packed-browser suites prove transient
failure followed by successful retry without reloading. Engine/index
fallback policy remains consumer-owned; this change does not mask backend
failures as successful empty results.

## History is empty after cutover, though old entries exist

**Symptom.** After cutover, the recent-searches panel is empty even though
the browser's localStorage still holds the consumer's old history payload.
No error is logged.

**Cause.** A storage-key or payload-shape mismatch, silently dropped. The
store reads exactly one key (default `type-anywhere-search-history`; the
consumer's key via `SearchHistory.setStorageKey`) and validates every entry:
a string `query` and a **numeric `timestamp`**. The EffortlessSteven cutover
hit exactly this — its pre-package history used a `ts` field, so every legacy
entry failed validation and was dropped silently, and entries under the old
key were invisible to the new one.

**Fix.** Before the component mounts, point the store at the consumer key and
migrate legacy shapes once:

```ts
SearchHistory.setStorageKey("my-existing-search-history");
try {
  const raw = localStorage.getItem("my-existing-search-history");
  const entries = raw ? JSON.parse(raw) : null;
  if (Array.isArray(entries) && entries.some((e) => typeof e?.ts === "number")) {
    localStorage.setItem(
      "my-existing-search-history",
      JSON.stringify(
        entries
          .filter((e) => typeof e?.query === "string")
          .map((e) => ({
            query: e.query,
            timestamp: typeof e.ts === "number" ? e.ts : Date.now(),
            ...(typeof e.resultCount === "number" ? { resultCount: e.resultCount } : {}),
          })),
      ),
    );
  }
} catch { /* leave history empty rather than crash boot */ }
```

**Verify.** With legacy entries in place, cut over, open the dialog, focus
the empty input: the panel lists the migrated entries with result counts and
dates. A deliberately corrupt payload must leave the panel empty but never
break boot.

## Tailwind does not generate CSS for the dialog (`ocean-*` classes)

**Symptom.** On a Tailwind v4 consumer, the dialog renders functionally
correct but visually unstyled — no colors, no backdrop, tokens like
`bg-ocean-deep` and `text-ocean-deep` produce no CSS.

**Cause.** Tailwind v4's content detection scans source files and skips
`node_modules` by default. The package's class names live inside the
installed package's `dist/`, so no utility CSS is generated for them. The
same scan-skip applies to any consumer-installed package. Separately, the
`ocean-*` tokens are inherited Under the Sea presentation names — they must
be mapped into the consumer's theme regardless of detection.

**Fix.** Both halves, in the consumer:

1. Add an explicit source so Tailwind scans the installed package, e.g. in
   the consumer's main CSS:

   ```css
   @source "../node_modules/type-anywhere-search/dist";
   ```

2. Define the `ocean-*` color tokens (deep/top/light/dark) in the consumer's
   theme with the site's palette — CSS variables or `@theme` entries — so the
   generated utilities resolve to real colors.

**Verify.** Build the consumer and inspect the emitted CSS for
`.bg-ocean-deep` / `.text-ocean-deep` (or the mapped values), then open the
dialog: backdrop, selected row, and tag chips are styled. This is the
Tailwind v4 half of the styling seam in the [migration guide](migration.md).

## Peer-dependency warnings or two Preact copies after install

**Symptom.** `pnpm install` warns that `type-anywhere-search`
expects `preact@^10.29.8`; or the app breaks subtly (hooks misbehave, child
context lost, duplicated preact in the bundle graph) even though versions
look close.

**Cause.** Version skew between the consumer's Preact and the `^10.29.8`
peer. Preact must exist as a single instance per page; two copies — one for
the consumer, one resolved for the package — break hooks and context in ways
that rarely point at the real cause.

**Fix.** Align the consumer on `preact@^10.29.8` (both real consumers pin
`10.29.8`), and if the graph still resolves two copies, dedupe from the
consumer with a pnpm override:

```json
{ "pnpm": { "overrides": { "preact": "^10.29.8" } } }
```

**Verify.** `pnpm why preact` shows one version in the consumer's graph; the
install emits no peer warning for the package; the dialog mounts, opens on
`/`, and keyboard navigation works in the consumer's e2e.
