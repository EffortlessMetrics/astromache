# Install from a packed artifact

Published `type-anywhere-search@0.1.1` remains an immutable registry baseline.
The current `0.1.3` review candidate is unpublished. Candidate consumption is by
**vendored tarball**: pack the package, check it into the consumer repository
under `vendor/`, install it through a `file:` spec, and record a receipt that
identifies the exact artifact and source commit. Both genuine consumers
(Carcinisation, EffortlessSteven) use this pattern.

## 1. Pack the package

From a clean checkout of this repository at the commit you intend to consume:

```bash
pnpm install --frozen-lockfile
pnpm pack --pack-destination .
sha256sum type-anywhere-search-0.1.3.tgz
```

`prepack` runs the build, so a packed tarball always carries a fresh `dist/`.
The pack lane in `pnpm verify:repo` independently checks the tarball inventory
(dist output + declarations only, no sources/tests/credentials), so a
consumer-vendored tarball is the same artifact shape the repository proves.

## 2. Vendor and verify

Copy the tarball into the consumer and record its digest:

```bash
mkdir -p vendor/type-anywhere-search
cp type-anywhere-search-0.1.3.tgz vendor/type-anywhere-search/
cd vendor/type-anywhere-search
sha256sum -c <(echo "<sha256>  type-anywhere-search-0.1.3.tgz")
```

Then pin the dependency with a `file:` spec:

```json
{
  "dependencies": {
    "type-anywhere-search": "file:vendor/type-anywhere-search/type-anywhere-search-0.1.3.tgz"
  }
}
```

```bash
pnpm install
```

A `file:` tarball spec (not a directory spec) is load-bearing: pnpm copies and
extracts the archive into the consumer's store, so builds never resolve
package files through a path that only exists on one machine.

## 3. Write the receipt

Vendoring without a receipt loses provenance. Both consumers ship a
`vendor/type-anywhere-search/RECEIPT.json` with this shape (Carcinisation's,
from its cutover, is the reference):

```json
{
  "schemaVersion": 1,
  "package": "type-anywhere-search",
  "version": "0.1.0",
  "sourceRepository": "EffortlessMetrics/type-anywhere-search",
  "sourceCommit": "<40-hex commit the tarball was packed from>",
  "tarball": "effortlessmetrics-type-anywhere-search-0.1.0.tgz",
  "tarballSha256": "<sha256 of the vendored tarball>",
  "packedAt": "<YYYY-MM-DD>",
  "consumption": {
    "packageJsonSpec": "file:vendor/type-anywhere-search/effortlessmetrics-type-anywhere-search-0.1.0.tgz"
  }
}
```

The consumer's verification lane should hash-check the vendored tarball on
every run (Carcinisation's seam verifier does), so a corrupted or swapped
tarball fails loudly instead of silently consuming the wrong code.

## Why the git form is not used

The `github:EffortlessMetrics/type-anywhere-search#<sha>` dependency form
installs and smoke-imports fine **with repository read auth on a developer
machine**, but it fails in consumer CI: the default `GITHUB_TOKEN` is scoped
to the consuming repository, and consumer workflows check out with
`persist-credentials: false`, so the private git fetch is rejected
(`remote: Repository not found. fatal: Authentication failed` — reproduced
locally with no credential helper). A cross-repository token (fine-grained
PAT or GitHub App installation) would be required before any consumer can
flip to the git form. Until that exists, the vendored tarball plus receipt is
the recorded consumption path. This is recorded in the Carcinisation receipt's
`whyNotGitForm` field and its issue tracker.

## Updating the pin

1. Pack the new artifact at the new source commit; record tarball sha256.
2. Replace the vendored tarball and `RECEIPT.json` in one consumer commit.
3. Rerun the consumer's verification lane (hash check + search suites).
4. Report the re-pin back to this repository so
   [`docs/governance/publish-preparation.md`](../governance/publish-preparation.md)
   or a new current source-and-digest receipt records the qualified pin. The
   private-candidate receipt remains historical.
