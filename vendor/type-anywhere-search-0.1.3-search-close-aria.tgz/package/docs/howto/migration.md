# Migrating from a local interaction implementation

This guide is for a consumer that implemented its own type-anywhere search
interaction (the Under-the-C / EffortlessSteven pattern) and wants to replace
that local code with the package. Carcinisation did exactly this cutover; its
receipts and parity suites are the reference run.

## What stays site-local

The package deliberately does **not** absorb these. Keep them in the consumer
and plug them into the ports:

| Consumer-owned | Lands behind |
| --- | --- |
| Search engine (MiniSearch or another), index schema and generation | `SearchBackendPort.search` / `getAllDocuments` |
| Worker lifecycle, inline fallback, engine errors | `SearchBackendPort.init` / `isReady` / `search` throws |
| Cache, persistence, memory budgets | inside the adapter; advisories via `onMemoryPressure` / `onPerformanceViolation` |
| Domain filters and result metadata | `SearchResultItem` extra fields + `renderResultMeta` |
| Routing and navigation (including view transitions) | `SearchNavigationPort.getResultHref` / `navigate` |
| Result rendering and copy | `renderResultMeta`, `labels`, consumer CSS |
| Analytics identity and privacy policy | `SearchAnalyticsPort` (`trackEvent` semantics, `trackSemanticEvent` bridge) |

Rule of thumb: if it names your engine, domain, routes, provider, or theme,
it stays with you and appears in the adapter — not in the package.

## What the package replaces

Delete the consumer-local equivalents only after parity is proven:

- **Global activation** — printable-key, `/`, and Cmd/Ctrl+K listeners,
  editable-element and IME/composition safety.
- **Dialog and focus lifecycle** — open/close, overlay click-outside, input
  focus acquisition and cursor placement, Escape teardown.
- **Query, debounce, and stale-result state** — 300 ms debounce,
  cancellation, monotonic request identity so only the newest search
  publishes.
- **Readiness handshake and admission gate** — the cold deep-link fix: a
  non-empty query arriving before the backend is ready does not execute, and
  unavailable is never rendered as a zero-result answer.
- **Keyboard selection and activation** — arrows, vim `j`/`k`, `g`/`G`,
  Enter, `x` clear-filters, with interactive controls inside results keeping
  their own activation.
- **Accessible announcements** — the polite live region and
  selected-result ARIA semantics.
- **History** — recent-searches panel, dedupe, caps, storage — behind
  `SearchHistoryPort` (the package ships a localStorage default).
- **Semantic analytics events** — `search`, `zero_results`, `click`,
  `filter`, `clear` — provider-agnostic.

Carcinisation removed 26 superseded local interaction copies after its
unchanged consumer suites passed; follow that order — package first, parity,
then deletion. Do not delete consumer-owned backend/adapters.

## Minimal adapter

```tsx
import {
  TypeAnywhereSearch,
  SearchHistory,
  type SearchBackendPort,
  type SearchNavigationPort,
  type SearchAnalyticsPort,
} from "type-anywhere-search";

const backend: SearchBackendPort = {
  async init() { await myEngine.ready; },          // stay pending until answerable
  isReady: () => myEngine.state === "ready",       // recovery probe
  async search(query, { tags, limit }) {
    if (!myEngine.canAnswer) throw new Error("engine unavailable"); // never fabricate
    return { results: myEngine.search(query).slice(0, limit) };
  },
  getAllDocuments: () => myEngine.allDocuments(),
};

const navigation: SearchNavigationPort = {
  getResultHref: (r) => `/projects/${r.slug}`,
  navigate: (href) => myRouter.navigate(href),      // omit for full page load
};

const analytics: SearchAnalyticsPort = {
  trackEvent: (name, props) => myMetrics.interaction(name, props),
  trackSemanticEvent: (name, props) => myProvider.event(name, props),
};
```

## Storage-key continuity

If the consumer already has search history in localStorage, keep it across
cutover by pointing the package's store at the existing key **before the
component mounts**:

```ts
SearchHistory.setStorageKey("my-existing-search-history");
```

The store reads whatever is under that key and validates entries (string
`query`, numeric `timestamp`); anything else is dropped silently. If the old
payload uses a different field name (for example `ts` instead of
`timestamp`), migrate it once at startup — see
[troubleshooting](troubleshooting.md) for the silent-drop symptom.

## Labels

The default copy says "projects" because it was extracted from a projects
site. Override the words without forking code:

```tsx
<TypeAnywhereSearch
  {...props}
  labels={{
    dialogLabel: "Search articles",
    inputPlaceholder: "Type to search articles... (/ to focus)",
    semanticSearchEvent: "Site Search",
    semanticResultClickEvent: "Article Click",
  }}
/>
```

## Styling seam

The shipped markup carries Tailwind utility classes, including `ocean-*`
color tokens inherited from the source product's Under the Sea theme
(`ocean-deep`, `ocean-top`, `ocean-light`, `ocean-dark`). The package does not
ship a theme and does not own your visual identity. Consumers so far have:

1. **Mapped the `ocean-*` tokens into their own theme** — define those color
   tokens (CSS variables or Tailwind theme entries) with the consumer's
   palette so the dialog matches the site. The tokens are the entire
   presentation contract; no other package class names are load-bearing.
2. **For Tailwind v4 consumers, added an `@source` entry** pointing at the
   installed package so content detection scans it — Tailwind skips
   `node_modules` by default, and without this the dialog's classes generate
   no CSS and render unstyled. See
   [troubleshooting](troubleshooting.md#tailwind-does-not-generate-css-for-the-dialog-ocean--classes).

Restyling beyond the tokens (layout, density, dark mode) is ordinary CSS on
the consumer side; the DOM structure and `data-`/ARIA hooks documented in the
[API reference](../reference/api.md) are the stable seam.

### Dark themes: surface tokens

Since 0.1.0 the dialog neutrals are semantic CSS variables, not hardcoded
light classes. A dark-themed consumer overrides the variables under its own
selector — no theme prop exists by design. In the consumer's stylesheet
(EffortlessSteven keys dark mode off `html[data-theme="dark"]`):

```css
html[data-theme="dark"] {
  --tas-surface: #0b1220;       /* dialog panel */
  --tas-surface-muted: #111c33; /* filters bar, footer */
  --tas-border: #24304a;
  --tas-text: #cbd5e1;
  --tas-text-muted: #94a3b8;
  --tas-text-faint: #64748b;
  /* full token table: docs/reference/api.md#styling-tokens-dark-theme-seam */
}
```

The package injects the light defaults as zero-specificity `:where(:root)`
rules and each utility also carries the default as a `var()` fallback, so the
unthemed appearance is byte-stable (light consumers need no action) and the
override wins under any ancestor selector. The `ocean-*` accent mapping above
still applies on top — accents and surfaces are independent seams.

## Test-hook gating

The library reports what your adapter subscribes to — including forced
performance violations — and stays silent otherwise. Deciding *when* to force
or surface those signals (development only, a CI flag, a query parameter) is
a consumer-side policy decision. Carcinisation gates its forced
violation hooks behind its own ADR-014-controlled environment checks; that
gating is consumer code, not package behavior. Keep the same discipline in
your adapters so production users never see test-only alerts.

## Parity checklist before deleting local code

- [ ] Activation: printable, `/`, Cmd/Ctrl+K; nothing fires in inputs/IME.
- [ ] Cold deep-link: `?q=` with a slow index executes exactly once, after readiness.
- [ ] Zero-result vs unavailable states are visually and semantically distinct.
- [ ] Stale results: fast successive queries never paint an older answer.
- [ ] Keyboard, focus return, history, announcements in your e2e suite.
- [ ] Analytics events match the pre-cutover names/properties you rely on.
- [ ] Consumer suites green; then remove superseded local interaction copies.
